import javax.naming.ServiceUnavailableException;
import javax.xml.transform.Source;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.StringTokenizer;



public class ThirdTest {
 
    public static void main(String[] a) {
        String pathName = "D:\\java实验\\采购清单.txt";
        int  sum = 0;

        try (InputStreamReader reader = new InputStreamReader(new FileInputStream(pathName), StandardCharsets.UTF_8))
        {
            BufferedReader br = new BufferedReader(reader);
            String str = br.readLine();
            while(str != null)
            {
                StringTokenizer tokenizer = new StringTokenizer(str.replaceAll("\\D",  ","), ",");
                while(tokenizer.hasMoreTokens()){
                    int A = Integer.parseInt(tokenizer.nextToken());
                    int B = Integer.parseInt(tokenizer.nextToken());
                    sum += A * B;
                }
                str = br.readLine();

            }
            
            br.close();
            System.out.println("总价是" + sum);
        }
        
        catch(IOException e){
            e.printStackTrace();
        }
    }
}      


   
  
  
