import java.io.*;
import java.util.Random;

public class SecondTest{
    public static void main(String args[]) throws IOException{
        BufferedReader br = new BufferedReader(new FileReader("名单.txt"));
        String[] ans = new String[10] ;
        String s = br.readLine();
        int i = 0;
        while(s != null){
            ans[i++] = s;
            s = br.readLine();
        }
        br.close();

        for(int j=0 ; j<3; j++){
            int num = (int) (Math.random()*5 + 1);
            System.out.println(ans[num]);
        }
    }
}