import java.util.Scanner;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class OneCalendor{
    public static void main(String args[]){
        Scanner reader = new Scanner(System.in);
        System.out.println("请输入年份");
        int year = reader.nextInt();
        System.out.println("请输入月份");
        int month = reader.nextInt();

        boolean f = false;
        if(year%4 == 0 && year%100!=0 || year %400 == 0){
            f = true; 
        }

        int sum = 0;
        for(int i=1900; i<year; i++){
            if(i%4==0 && i%100!=0 || i%400==0){
                sum += 366;
            }
            else{
                sum += 365;
            }
        }
        for(int i=1; i<month; i++){
            if(i == 2){
                if(f){
                    sum += 29;
                }
                else{
                    sum += 28;
                }
            }
            else{
                if(i==4 || i==6 || i==9 || i==11){
                    sum += 30;
                }
                else{
                    sum += 31;
                }
            }
        }
        sum += 1;
        int day = sum % 7;
        System.out.print("======================================================\n");
        System.out.println(year + "年" + month + "月");
        System.out.println("日\t一\t二\t三\t四\t五\t六");
        for(int i=1; i<=day; i++)
        {
            System.out.print("\t");
        }
   


        int d;
        if(f && month == 2){
            d = 29;
        }
        else if(!f && month == 2){
            d = 28;
        }
        else if(month == 4 || month == 6 || month == 9 || month == 11){
            d = 30;
        }
        else{
            d = 31;
        }
    
        for(int i=1; i<=d; i++){
            if(sum%7 == 6){
                System.out.print(i+"\n");
            }
            else{
                System.out.print(i+"\t");
            }
            sum++;
        }

        System.out.print("\n======================================================\n");


    }

  
    
}