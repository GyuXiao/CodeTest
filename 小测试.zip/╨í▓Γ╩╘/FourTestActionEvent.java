import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class FourTestActionEvent{
    public static void main(String args[]){
        JFrame f = new JFrame("Test");
        JButton b1 = new JButton("-");
        JButton b2 = new JButton("+");
        JLabel ans = new JLabel("0", JLabel.CENTER);
        Monitor bh = new Monitor();
        f.setLayout(new GridLayout());
        bh.setJLabel(ans);
        f.add(b1);
        f.add(ans);
        f.add(b2);

        b1.setActionCommand("-");
        b2.setActionCommand("+");

        b1.addActionListener(bh);
        b2.addActionListener(bh);

        f.pack();
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}



class Monitor implements ActionListener{
    int cnt = 0;
    JLabel ans ;
    public void setJLabel (JLabel ans){
        this.ans = ans;
    }

    public void actionPerformed(ActionEvent e){
        String str = e.getActionCommand();

        if(str.equals("-"))
        {
            if(cnt > 0 )//减到0
                cnt--;
        }
        else
        {
            cnt++;//无上限
        }

        ans.setText("" + cnt);
    }
}